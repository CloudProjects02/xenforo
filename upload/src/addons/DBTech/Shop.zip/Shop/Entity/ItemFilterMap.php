<?php

namespace DBTech\Shop\Entity;

use XF\Mvc\Entity\Structure;
use XF\Mvc\Entity\Entity;

/**
 * COLUMNS
 * @property int $item_id
 * @property string $filter_id
 *
 * RELATIONS
 * @property \DBTech\Shop\Entity\Item $Item
 */
class ItemFilterMap extends Entity
{
	/**
	 * @param \XF\Mvc\Entity\Structure $structure
	 *
	 * @return \XF\Mvc\Entity\Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_shop_item_filter_map';
		$structure->shortName = 'DBTech\Shop:ItemFilterMap';
		$structure->primaryKey = ['item_id', 'filter_id'];
		$structure->columns = [
			'item_id' => ['type' => self::UINT, 'required' => true],
			'filter_id' => ['type' => self::BINARY, 'maxLength' => 25, 'required' => true]
		];
		$structure->getters = [];
		$structure->relations = [
			'Item' => [
				'entity' => 'DBTech\Shop:Item',
				'type' => self::TO_ONE,
				'conditions' => 'item_id',
				'primary' => true
			]
		];

		return $structure;
	}
}