<?php

namespace DBTech\Shop\Pub\View\Lottery;

class ViewTickets extends \XF\Mvc\View
{
}