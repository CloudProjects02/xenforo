<?php

namespace DBTech\Shop\Pub\View\Item;

class EditIcon extends \XF\Mvc\View
{
}