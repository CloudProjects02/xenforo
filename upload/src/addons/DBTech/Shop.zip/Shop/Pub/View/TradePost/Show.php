<?php

namespace DBTech\Shop\Pub\View\TradePost;

class Show extends \XF\Mvc\View
{
}