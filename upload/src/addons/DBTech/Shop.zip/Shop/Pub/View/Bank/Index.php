<?php

namespace DBTech\Shop\Pub\View\Bank;

class Index extends \XF\Mvc\View
{
}