<?php

namespace DBTech\Shop\Pub\View\Checkout;

class Recipient extends \XF\Mvc\View
{
}