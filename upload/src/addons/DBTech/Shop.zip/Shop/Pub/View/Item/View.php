<?php

namespace DBTech\Shop\Pub\View\Item;

class View extends \XF\Mvc\View
{
}