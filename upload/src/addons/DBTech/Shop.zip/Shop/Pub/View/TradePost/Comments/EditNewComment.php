<?php

namespace DBTech\Shop\Pub\View\TradePost\Comments;

class EditNewComment extends \XF\Mvc\View
{
}