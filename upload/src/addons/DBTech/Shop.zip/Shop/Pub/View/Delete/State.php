<?php

namespace DBTech\Shop\Pub\View\Delete;

class State extends \XF\Mvc\View
{
}