<?php

namespace DBTech\Shop\Pub\View\TradePost\Comments;

class Show extends \XF\Mvc\View
{
}