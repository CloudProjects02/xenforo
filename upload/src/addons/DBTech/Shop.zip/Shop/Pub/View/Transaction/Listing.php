<?php

namespace DBTech\Shop\Pub\View\Transaction;

class Listing extends \XF\Mvc\View
{
}