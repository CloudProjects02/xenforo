<?php

namespace DBTech\Shop\Pub\View\TradePost;

class Edit extends \XF\Mvc\View
{
}