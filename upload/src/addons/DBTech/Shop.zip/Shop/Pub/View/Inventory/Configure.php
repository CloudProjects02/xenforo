<?php

namespace DBTech\Shop\Pub\View\Inventory;

class Configure extends \XF\Mvc\View
{
}