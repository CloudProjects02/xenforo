<?php

namespace DBTech\Shop\Pub\View\Transaction;

class View extends \XF\Mvc\View
{
}