<?php

namespace DBTech\Shop\Pub\View\Item;

class Purchase extends \XF\Mvc\View
{
}