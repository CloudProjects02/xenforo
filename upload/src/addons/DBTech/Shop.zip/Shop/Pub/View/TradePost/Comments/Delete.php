<?php

namespace DBTech\Shop\Pub\View\TradePost\Comments;

class Delete extends \XF\Mvc\View
{
}