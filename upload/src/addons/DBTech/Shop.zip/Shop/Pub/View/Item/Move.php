<?php

namespace DBTech\Shop\Pub\View\Item;

class Move extends \XF\Mvc\View
{
}