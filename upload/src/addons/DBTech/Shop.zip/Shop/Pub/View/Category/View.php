<?php

namespace DBTech\Shop\Pub\View\Category;

class View extends \XF\Mvc\View
{
}