<?php

namespace DBTech\Shop\Pub\View\Inventory;

class Sell extends \XF\Mvc\View
{
}