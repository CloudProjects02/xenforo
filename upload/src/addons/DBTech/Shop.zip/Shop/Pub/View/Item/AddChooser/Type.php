<?php

namespace DBTech\Shop\Pub\View\Item\AddChooser;

class Type extends \XF\Mvc\View
{
}