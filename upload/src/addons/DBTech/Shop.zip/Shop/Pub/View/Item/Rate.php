<?php

namespace DBTech\Shop\Pub\View\Item;

class Rate extends \XF\Mvc\View
{
}