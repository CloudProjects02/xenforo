<?php

namespace DBTech\Shop\Pub\View\Item;

class Delete extends \XF\Mvc\View
{
}