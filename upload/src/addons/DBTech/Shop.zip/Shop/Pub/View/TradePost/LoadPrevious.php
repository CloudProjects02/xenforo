<?php

namespace DBTech\Shop\Pub\View\TradePost;

class LoadPrevious extends \XF\Mvc\View
{
}