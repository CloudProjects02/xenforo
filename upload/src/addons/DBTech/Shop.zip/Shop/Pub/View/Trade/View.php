<?php

namespace DBTech\Shop\Pub\View\Trade;

class View extends \XF\Mvc\View
{
}