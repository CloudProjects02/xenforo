<?php

namespace DBTech\Shop\Pub\View\Item;

class Tags extends \XF\Mvc\View
{
}