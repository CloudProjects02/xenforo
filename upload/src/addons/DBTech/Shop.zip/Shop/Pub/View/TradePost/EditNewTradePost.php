<?php

namespace DBTech\Shop\Pub\View\TradePost;

class EditNewTradePost extends \XF\Mvc\View
{
}