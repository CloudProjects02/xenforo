<?php

namespace DBTech\Shop\Pub\View\Lottery;

class ListView extends \XF\Mvc\View
{
}