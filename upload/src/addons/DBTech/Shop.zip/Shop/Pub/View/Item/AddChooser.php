<?php

namespace DBTech\Shop\Pub\View\Item;

class AddChooser extends \XF\Mvc\View
{
}