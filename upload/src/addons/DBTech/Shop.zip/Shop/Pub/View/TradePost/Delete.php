<?php

namespace DBTech\Shop\Pub\View\TradePost;

class Delete extends \XF\Mvc\View
{
}