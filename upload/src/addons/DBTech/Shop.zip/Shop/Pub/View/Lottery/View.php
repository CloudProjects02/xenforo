<?php

namespace DBTech\Shop\Pub\View\Lottery;

class View extends \XF\Mvc\View
{
}