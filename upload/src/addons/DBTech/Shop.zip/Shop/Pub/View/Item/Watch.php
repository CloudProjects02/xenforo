<?php

namespace DBTech\Shop\Pub\View\Item;

class Watch extends \XF\Mvc\View
{
}