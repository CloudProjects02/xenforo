<?php

namespace DBTech\Shop\Pub\View\Item;

class Find extends \XF\Mvc\View
{
}