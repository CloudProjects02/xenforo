<?php

namespace DBTech\Shop\Pub\View\Checkout;

class RemoveItem extends \XF\Mvc\View
{
}