<?php

namespace DBTech\Shop\Pub\View\Inventory;

class Settings extends \XF\Mvc\View
{
}