<?php

namespace DBTech\Shop\Pub\View\Item;

class Reviews extends \XF\Mvc\View
{
}