<?php

namespace DBTech\Shop\Pub\View\Inventory\Purchase;

class View extends \XF\Mvc\View
{
}