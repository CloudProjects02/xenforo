<?php

namespace DBTech\Shop\Pub\View;

class Overview extends \XF\Mvc\View
{
}