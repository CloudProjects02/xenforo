<?php

namespace DBTech\Shop\Pub\View\Trade;

class Accept extends \XF\Mvc\View
{
}