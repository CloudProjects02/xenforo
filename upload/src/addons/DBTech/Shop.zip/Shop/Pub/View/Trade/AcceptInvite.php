<?php

namespace DBTech\Shop\Pub\View\Trade;

class AcceptInvite extends \XF\Mvc\View
{
}