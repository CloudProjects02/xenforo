<?php

namespace DBTech\Shop\Pub\View\ItemReview;

class Delete extends \XF\Mvc\View
{
}