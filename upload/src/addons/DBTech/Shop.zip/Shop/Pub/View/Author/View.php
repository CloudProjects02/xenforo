<?php

namespace DBTech\Shop\Pub\View\Author;

class View extends \XF\Mvc\View
{
}