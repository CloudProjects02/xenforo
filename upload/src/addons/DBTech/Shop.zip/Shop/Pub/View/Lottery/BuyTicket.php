<?php

namespace DBTech\Shop\Pub\View\Lottery;

class BuyTicket extends \XF\Mvc\View
{
}