<?php

namespace DBTech\Shop\Pub\View\Bank;

class Deposit extends \XF\Mvc\View
{
}