<?php

namespace DBTech\Shop\Pub\View\TradePost\Comments;

class Edit extends \XF\Mvc\View
{
}