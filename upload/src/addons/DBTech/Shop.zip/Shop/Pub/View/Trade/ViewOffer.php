<?php

namespace DBTech\Shop\Pub\View\Trade;

class ViewOffer extends \XF\Mvc\View
{
}