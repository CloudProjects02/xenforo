<?php

namespace DBTech\Shop\Pub\View\Inventory;

class Discard extends \XF\Mvc\View
{
}