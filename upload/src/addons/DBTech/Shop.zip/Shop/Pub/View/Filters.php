<?php

namespace DBTech\Shop\Pub\View;

class Filters extends \XF\Mvc\View
{
}