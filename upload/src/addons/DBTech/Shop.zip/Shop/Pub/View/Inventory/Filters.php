<?php

namespace DBTech\Shop\Pub\View\Inventory;

class Filters extends \XF\Mvc\View
{
}