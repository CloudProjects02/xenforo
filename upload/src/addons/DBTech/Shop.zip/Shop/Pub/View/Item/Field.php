<?php

namespace DBTech\Shop\Pub\View\Item;

class Field extends \XF\Mvc\View
{
}