<?php

namespace DBTech\Shop\Pub\View\Trade;

class NewTradePosts extends \XF\Mvc\View
{
}