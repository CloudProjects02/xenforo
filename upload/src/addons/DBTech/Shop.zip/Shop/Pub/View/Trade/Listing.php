<?php

namespace DBTech\Shop\Pub\View\Trade;

class Listing extends \XF\Mvc\View
{
}