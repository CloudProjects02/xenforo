<?php

namespace DBTech\Shop\Pub\View\Checkout;

class Index extends \XF\Mvc\View
{
}