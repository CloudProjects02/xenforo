<?php

namespace DBTech\Shop\Pub\View;

class Steal extends \XF\Mvc\View
{
}