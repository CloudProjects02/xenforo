<?php

namespace DBTech\Shop\Pub\View\Trade;

class Modify extends \XF\Mvc\View
{
}