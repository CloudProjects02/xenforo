<?php

namespace DBTech\Shop\Pub\View;

class LatestReviews extends \XF\Mvc\View
{
}