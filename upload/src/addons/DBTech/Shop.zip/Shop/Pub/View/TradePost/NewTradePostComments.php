<?php

namespace DBTech\Shop\Pub\View\TradePost;

class NewTradePostComments extends \XF\Mvc\View
{
}