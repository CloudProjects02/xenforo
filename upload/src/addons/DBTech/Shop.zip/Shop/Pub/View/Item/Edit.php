<?php

namespace DBTech\Shop\Pub\View\Item;

class Edit extends \XF\Mvc\View
{
}