<?php

namespace DBTech\Shop\Pub\View\Item;

class Reassign extends \XF\Mvc\View
{
}