<?php

namespace DBTech\Shop\Pub\View\WhatsNew;

class TradePosts extends \XF\Mvc\View
{
}