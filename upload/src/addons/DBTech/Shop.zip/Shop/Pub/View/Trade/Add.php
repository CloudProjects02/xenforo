<?php

namespace DBTech\Shop\Pub\View\Trade;

class Add extends \XF\Mvc\View
{
}