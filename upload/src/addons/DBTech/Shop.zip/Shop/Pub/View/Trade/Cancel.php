<?php

namespace DBTech\Shop\Pub\View\Trade;

class Cancel extends \XF\Mvc\View
{
}