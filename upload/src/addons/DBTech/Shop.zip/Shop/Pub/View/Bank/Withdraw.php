<?php

namespace DBTech\Shop\Pub\View\Bank;

class Withdraw extends \XF\Mvc\View
{
}