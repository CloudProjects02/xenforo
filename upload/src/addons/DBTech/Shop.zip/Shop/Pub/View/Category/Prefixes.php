<?php

namespace DBTech\Shop\Pub\View\Category;

class Prefixes extends \XF\Mvc\View
{
}