<?php

namespace DBTech\Shop\Pub\View\Inventory;

class Gift extends \XF\Mvc\View
{
}