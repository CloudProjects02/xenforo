<?php

namespace DBTech\Shop\Pub\View\Category;

class Watch extends \XF\Mvc\View
{
}