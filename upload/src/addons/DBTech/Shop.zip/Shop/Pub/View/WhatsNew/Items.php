<?php

namespace DBTech\Shop\Pub\View\WhatsNew;

class Items extends \XF\Mvc\View
{
}