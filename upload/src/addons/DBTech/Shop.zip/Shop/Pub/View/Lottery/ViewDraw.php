<?php

namespace DBTech\Shop\Pub\View\Lottery;

class ViewDraw extends \XF\Mvc\View
{
}