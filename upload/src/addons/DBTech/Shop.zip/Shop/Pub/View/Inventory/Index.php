<?php

namespace DBTech\Shop\Pub\View\Inventory;

class Index extends \XF\Mvc\View
{
}