<?php

namespace DBTech\Shop\Admin\View\Log\Transaction;

class Listing extends \XF\Mvc\View
{
}