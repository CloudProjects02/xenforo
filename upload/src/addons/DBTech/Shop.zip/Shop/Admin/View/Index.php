<?php

namespace DBTech\Shop\Admin\View;

class Index extends \XF\Mvc\View
{
}