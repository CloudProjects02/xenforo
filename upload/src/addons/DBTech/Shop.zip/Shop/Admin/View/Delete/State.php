<?php

namespace DBTech\Shop\Admin\View\Delete;

class State extends \XF\Mvc\View
{
}