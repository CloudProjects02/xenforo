<?php

namespace DBTech\Shop\Admin\View\Purchase;

class Edit extends \XF\Mvc\View
{
}