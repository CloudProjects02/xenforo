<?php

namespace DBTech\Shop\Admin\View\Log\Transaction;

class Search extends \XF\Mvc\View
{
}