<?php

namespace DBTech\Shop\Admin\View\Currency;

class Edit extends \XF\Mvc\View
{
}