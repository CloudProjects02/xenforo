<?php

namespace DBTech\Shop\Admin\View\Item;

class Reassign extends \XF\Mvc\View
{
}