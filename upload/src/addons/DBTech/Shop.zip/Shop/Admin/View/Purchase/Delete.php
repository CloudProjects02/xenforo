<?php

namespace DBTech\Shop\Admin\View\Purchase;

class Delete extends \XF\Mvc\View
{
}