<?php

namespace DBTech\Shop\Admin\View\Lottery;

class Edit extends \XF\Mvc\View
{
}