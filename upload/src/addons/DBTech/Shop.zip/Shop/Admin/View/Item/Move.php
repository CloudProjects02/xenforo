<?php

namespace DBTech\Shop\Admin\View\Item;

class Move extends \XF\Mvc\View
{
}