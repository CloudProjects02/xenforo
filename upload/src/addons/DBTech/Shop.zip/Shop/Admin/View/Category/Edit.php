<?php

namespace DBTech\Shop\Admin\View\Category;

class Edit extends \XF\Mvc\View
{
}