<?php

namespace DBTech\Shop\Admin\View\Item;

class Listing extends \XF\Mvc\View
{
}