<?php

namespace DBTech\Shop\Admin\View\Item;

class Edit extends \XF\Mvc\View
{
}