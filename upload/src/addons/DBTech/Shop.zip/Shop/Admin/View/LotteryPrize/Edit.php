<?php

namespace DBTech\Shop\Admin\View\LotteryPrize;

class Edit extends \XF\Mvc\View
{
}