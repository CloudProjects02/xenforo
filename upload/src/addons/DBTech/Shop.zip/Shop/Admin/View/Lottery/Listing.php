<?php

namespace DBTech\Shop\Admin\View\Lottery;

class Listing extends \XF\Mvc\View
{
}