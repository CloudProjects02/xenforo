<?php

namespace DBTech\Shop\Admin\View\Permission;

class ItemOverview extends \XF\Mvc\View
{
}