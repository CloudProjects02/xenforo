<?php

namespace DBTech\Shop\Admin\View;

class Log extends \XF\Mvc\View
{
}