<?php

namespace DBTech\Shop\Admin\View\Permission;

class CategoryOverview extends \XF\Mvc\View
{
}