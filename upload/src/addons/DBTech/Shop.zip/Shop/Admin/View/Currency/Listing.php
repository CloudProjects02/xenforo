<?php

namespace DBTech\Shop\Admin\View\Currency;

class Listing extends \XF\Mvc\View
{
}