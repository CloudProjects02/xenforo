<?php

namespace DBTech\Shop\Admin\View\Purchase;

class AddChooser extends \XF\Mvc\View
{
}