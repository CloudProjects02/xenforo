<?php

namespace DBTech\Shop\Admin\View\Item\AddChooser;

class Type extends \XF\Mvc\View
{
}