<?php

namespace DBTech\Shop\Admin\View\Item;

class AddChooser extends \XF\Mvc\View
{
}