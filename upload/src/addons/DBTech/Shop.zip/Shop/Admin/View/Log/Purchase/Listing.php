<?php

namespace DBTech\Shop\Admin\View\Log\Purchase;

class Listing extends \XF\Mvc\View
{
}