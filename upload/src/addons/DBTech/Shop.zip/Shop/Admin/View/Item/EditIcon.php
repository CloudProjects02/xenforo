<?php

namespace DBTech\Shop\Admin\View\Item;

class EditIcon extends \XF\Mvc\View
{
}