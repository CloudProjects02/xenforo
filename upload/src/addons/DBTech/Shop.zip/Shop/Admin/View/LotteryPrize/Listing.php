<?php

namespace DBTech\Shop\Admin\View\LotteryPrize;

class Listing extends \XF\Mvc\View
{
}