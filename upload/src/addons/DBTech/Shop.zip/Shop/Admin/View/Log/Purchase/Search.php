<?php

namespace DBTech\Shop\Admin\View\Log\Purchase;

class Search extends \XF\Mvc\View
{
}