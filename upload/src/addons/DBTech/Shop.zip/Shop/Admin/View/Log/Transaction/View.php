<?php

namespace DBTech\Shop\Admin\View\Log\Transaction;

class View extends \XF\Mvc\View
{
}