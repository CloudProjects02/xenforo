<?php

namespace DBTech\Shop\Finder;

use XF\Mvc\Entity\Finder;

class TradingCard extends Finder
{
}