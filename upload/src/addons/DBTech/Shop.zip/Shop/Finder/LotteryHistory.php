<?php

namespace DBTech\Shop\Finder;

use XF\Mvc\Entity\Finder;

class LotteryHistory extends Finder
{
}