<?php

namespace DBTech\Shop\Finder;

use XF\Mvc\Entity\Finder;

class ItemFieldValue extends Finder
{
}